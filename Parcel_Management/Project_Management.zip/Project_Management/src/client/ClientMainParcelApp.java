package client;

import parcel.ParcelFrame;
import parcel.Parcel;
import parcel.ParcelManager;

public class ClientMainParcelApp 
{
	public static void main (String args [])
	{
		ParcelFrame parcelFrame = new ParcelFrame();
		parcelFrame.setVisible(true);
				
	}
}
