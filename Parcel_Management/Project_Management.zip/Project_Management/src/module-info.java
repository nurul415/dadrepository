module Project_Management 
{
	requires java.desktop;
	requires java.sql;
}